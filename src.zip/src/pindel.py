# -*- coding: utf-8 -*-
#将pindel识别出的断点与真实设置的断点写入同一个文件进行比较

import sys
import os
import datetime
import copy

def get_filename(filetype):
    filename = []
    for root, dirs, files in os.walk("."):#获取当前文件夹的路径，文件夹，以及所有文件
        for i in files:
            if filetype in i:
                if i[0 : 6] == 'delpos' and i != 'delpos0.txt' and i != 'delpos.txt':
                    filename.append(i)
    return filename

if __name__ == "__main__":
    line = ''
    totalline = ''
    with open(sys.argv[2], 'r') as Fileout:
        Fileout.readline()
        while True:
            line = Fileout.readline().strip('\n')
            if not line:
                break
            totalline += line
    Fileout.close()
    totalline = totalline.upper()

    filetype = '.txt'
    filename = get_filename(filetype)

    orf = []
    oridelCase2 = []
    oridel = []#存设置的deletion

    #读预先设置的deletion信息
    countd = 0
    print filename
    for i in range(0, len(filename)):
        ori = []
        with open(filename[i], 'r') as fpf:
            while True:
                line = fpf.readline().strip('\n')
                if not line:
                    break
                tmp = line.split()
                if int(tmp[1]) > 1000000 and int(tmp[1]) < 2000000:
                    delposi = tmp[1] + ' ' + tmp[2][1 : ]
                    oridelCase2.append(delposi)
                    continue
                delposi = tmp[1] + ' ' + tmp[2][1 : ]
                ori.append(delposi)
                countd += 1
        orf.append(ori)
        fpf.close()

    caseFile = []
    low = 0
    high = 0
    if sys.argv[1] == "1":
        for i in range(0, countd / len(filename)):
            for j in range(0, len(filename)):
                if orf[j][i] not in oridel:
                    oridel.append(orf[j][i])#将原设置的deletion读进来
        low = 0
        high = 1000000
        caseFile = ["case1.txt"]
    elif sys.argv[1] == "2":
        for i in oridelCase2:
            oridel.append(i)
        low = 1000000
        high = 2000000
        caseFile = ["case2.txt"]
    elif sys.argv[1] == "3":
        for i in range(0, countd / len(filename)):
            for j in range(0, len(filename)):
                if orf[j][i] not in oridel:
                    oridel.append(orf[j][i])#将原设置的deletion读进来
        for i in oridelCase2:
            oridel.append(i)
        low = 0
        high = 2000000
        caseFile = ["case1.txt", "case2.txt"]

    tolarence = int(sys.argv[3])

    for i in range(0, len(oridel)):
        delpos = int(oridel[i].split()[0])
        dellen = int(oridel[i].split()[1])
        leage1 = delpos - 1
        while(totalline[leage1] == totalline[leage1 + dellen]):
            leage1 -= 1
        start = leage1 + 1
        leage2 = delpos
        while(totalline[leage2] == totalline[leage2 + dellen]):
            leage2 += 1
        end = leage2
        if(start != end):
            oridel[i] = str(start) + "_" + str(end) + " " + oridel[i].split()[1]

    #SV-Del
    pdel = []
    for i in caseFile:
        with open(i, 'r') as Fileout:#读预测的deletion信息
            line = Fileout.readline()
            while True:
                line = Fileout.readline().strip('\n')
                if not line:
                    break
                recdelpos = line.split()[0] + " " + line.split()[1]
                pdel.append(recdelpos)
        Fileout.close()

    #Pindel
    pindel = []
    with open("pindel_result", 'r') as fp:#读pindel预测的deletion信息
        fp.readline()
        while True:
            line = fp.readline().strip('\n')
            if not line:
                break
            tmp = line.split()
            if int(tmp[0]) > low and int(tmp[0]) < high and int(tmp[2]) > 2:
                pdi = tmp[0] + " " + tmp[1]
                pindel.append(pdi)
    fp.close()

    #Swan
    swan = []
    with open("s150.sort.conf.bed", 'r') as fp:#读swan预测的deletion信息
        while True:
            line = fp.readline().strip('\n')
            if not line:
                break
            tmp = line.split()
            if int(tmp[1]) > low and int(tmp[1]) < high:
                pdi = tmp[1] + " " + str(int(tmp[2]) - int(tmp[1]))
                swan.append(pdi)
    fp.close()

    #Gatk
    gatk = []
    with open("s150indel.gatk.raw.vcf", 'r') as fp:#读gatk预测的deletion信息
        fp.readline()
        while True:
            line = fp.readline().strip('\n')
            if not line:
                break
            if line[0] == 'c':
                tmp = line.split()
                if int(tmp[1]) > low and int(tmp[1]) < high:
                    if len(tmp[3]) - len(tmp[4]) > 0:
                        pdi = tmp[1] + " " + str(len(tmp[3]) - len(tmp[4]))
                        gatk.append(pdi)
    fp.close()

    '''
    #VarScan
    VarScan = []
    with open("output.indel", 'r') as fp:#读Varscan预测的deletion信息
        fp.readline()
        while True:
            line = fp.readline().strip('\n')
            if not line:
                break
            tmp = line.split()
            if int(tmp[1]) > low and int(tmp[1]) < high:
                pdi = tmp[1] + " " + str(len(tmp[3]) - 1)
                VarScan.append(pdi)
    fp.close()
    '''

    #delly
    delly = []
    with open("s.tab", 'r') as fp:#读pindel预测的deletion信息
        fp.readline()
        while True:
            line = fp.readline().strip('\n')
            if not line:
                break
            tmp = line.split()
            if int(tmp[1]) > low and int(tmp[1]) < high:
                pdi = tmp[1] + " " + tmp[5]
                delly.append(pdi)
    fp.close()


    b = open("pindel_delpos.txt", 'w')
    minlen = min(len(oridel), len(pdel))
    b.write("设置的deletion：" + "  " + "识别出的deletion" + '\n')
    for i in range(0, minlen):
        b.write(oridel[i] + "       " +  pdel[i])
        b.write('\n')
    if minlen == len(oridel):
        #b.write('pdel left \n')
        for j in range(minlen, len(pdel)):
            b.write("                 " + pdel[j])
            b.write('\n')
    if minlen == len(pdel):
        #b.write('oridel left \n')
        for k in range(minlen, len(oridel)):
            b.write(oridel[k])
            b.write('\n')

    TP1 = 0
    FP1 = 0
    FN1 = 0
    TN1 = 0
    TP2 = 0
    FP2 = 0
    FN2 = 0
    TN2 = 0
    TP3 = 0
    FP3 = 0
    FN3 = 0
    TN3 = 0
    TP4 = 0
    FP4 = 0
    FN4 = 0
    TN4 = 0
    TP5 = 0
    FP5 = 0
    FN5 = 0
    TN5 = 0
    TP6 = 0
    FP6 = 0
    FN6 = 0
    TN6 = 0


    svdelCopyOridel = copy.deepcopy(oridel)
    for pde in pdel:
        if pde in svdelCopyOridel:
            TP1 += 1
            svdelCopyOridel.remove(pde)
        else:
            for i in range(0, len(svdelCopyOridel)):
                tmp = svdelCopyOridel[i].split()
                if('_' in tmp[0]):
                    pdmin = min(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    pdmax = max(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    if int(pde.split()[0]) >= pdmin and int(pde.split()[0]) <= pdmax and abs(int(pde.split()[1]) - int(tmp[1])) <= tolarence:
                        TP1 += 1
                        svdelCopyOridel.remove(svdelCopyOridel[i])
                        break
                    if abs(int(pde.split()[0]) - pdmin) <= tolarence or abs(int(pde.split()[0]) - pdmax) <= tolarence:
                        if abs(int(pde.split()[1]) - int(tmp[1])) <= tolarence:
                            TP1 += 1
                            svdelCopyOridel.remove(svdelCopyOridel[i])
                            break
                else:
                    if abs(int(pde.split()[0]) - int(tmp[0])) <= tolarence:
                        if abs(int(pde.split()[1]) - int(tmp[1])) <= tolarence:
                            TP1 += 1
                            svdelCopyOridel.remove(svdelCopyOridel[i])
                            break

    pindelCopyOridel = copy.deepcopy(oridel)
    for pindeldel in pindel:
        if pindeldel in pindelCopyOridel:
            TP2 += 1
            pindelCopyOridel.remove(pindeldel)
        else:
            for i in range(0, len(pindelCopyOridel)):
                tmp = pindelCopyOridel[i].split()
                if('_' in tmp[0]):
                    pdmin = min(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    pdmax = max(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    if int(pindeldel.split()[0]) >= pdmin and int(pindeldel.split()[0]) <= pdmax and abs(int(pindeldel.split()[1]) - int(tmp[1])) <= tolarence:
                        TP2 += 1
                        pindelCopyOridel.remove(pindelCopyOridel[i])
                        break
                    if abs(int(pindeldel.split()[0]) - pdmin) <= tolarence or abs(int(pindeldel.split()[0]) - pdmax) <= tolarence:
                        if abs(int(pindeldel.split()[1]) - int(tmp[1])) <= tolarence:
                            TP2 += 1
                            pindelCopyOridel.remove(pindelCopyOridel[i])
                            break
                else:
                    if abs(int(pindeldel.split()[0]) - int(tmp[0])) <= tolarence:
                        if abs(int(pindeldel.split()[1]) - int(tmp[1])) <= tolarence:
                            TP2 += 1
                            pindelCopyOridel.remove(pindelCopyOridel[i])
                            break

    gatkCopyOridel = copy.deepcopy(oridel)
    for gatkdel in gatk:
        if gatkdel in gatkCopyOridel:
            TP3 += 1
            gatkCopyOridel.remove(gatkdel)
            print gatkdel, gatkdel, "1"
        else:
            for i in range(0, len(gatkCopyOridel)):
                tmp = gatkCopyOridel[i].split()
                if('_' in tmp[0]):
                    pdmin = min(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    pdmax = max(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    if int(gatkdel.split()[0]) >= pdmin and int(gatkdel.split()[0]) <= pdmax and abs(int(gatkdel.split()[1]) - int(tmp[1])) <= tolarence:
                        TP3 += 1
                        print gatkCopyOridel[i], gatkdel, "2"
                        gatkCopyOridel.remove(gatkCopyOridel[i])
                        break
                    if abs(int(gatkdel.split()[0]) - pdmin) <= tolarence or abs(int(gatkdel.split()[0]) - pdmax) <= tolarence:
                        if abs(int(gatkdel.split()[1]) - int(tmp[1])) <= tolarence:
                            TP3 += 1
                            print gatkCopyOridel[i], gatkdel, "3"
                            gatkCopyOridel.remove(gatkCopyOridel[i])
                            break
                else:
                    if abs(int(gatkdel.split()[0]) - int(tmp[0])) <= tolarence:
                        if abs(int(gatkdel.split()[1]) - int(tmp[1])) <= tolarence:
                            TP3 += 1
                            print gatkCopyOridel[i], gatkdel, "4"
                            gatkCopyOridel.remove(gatkCopyOridel[i])
                            break

    swanCopyOridel = copy.deepcopy(oridel)
    for swandel in swan:
        if swandel in swanCopyOridel:
            TP4 += 1
            swanCopyOridel.remove(swandel)
        else:
            for i in range(0, len(swanCopyOridel)):
                tmp = swanCopyOridel[i].split()
                if('_' in tmp[0]):
                    pdmin = min(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    pdmax = max(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    if int(swandel.split()[0]) >= pdmin and int(swandel.split()[0]) <= pdmax and abs(int(swandel.split()[1]) - int(tmp[1])) <= tolarence:
                        TP4 += 1
                        swanCopyOridel.remove(swanCopyOridel[i])
                        break
                    if abs(int(swandel.split()[0]) - pdmin) <= tolarence or abs(int(swandel.split()[0]) - pdmax) <= tolarence:
                        if abs(int(swandel.split()[1]) - int(tmp[1])) <= tolarence:
                            TP4 += 1
                            swanCopyOridel.remove(swanCopyOridel[i])
                            break
                else:
                    if abs(int(swandel.split()[0]) - int(tmp[0])) <= tolarence:
                        if abs(int(swandel.split()[1]) - int(tmp[1])) <= tolarence:
                            TP4 += 1
                            swanCopyOridel.remove(swanCopyOridel[i])
                            break

    '''
    for Varscandel in VarScan:
        if Varscandel in oridel:
            TP5 += 1
        else:
            for i in range(0, len(oridel)):
                tmp = oridel[i].split()
                if('_' in tmp[0]):
                    pdmin = min(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    pdmax = max(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    if int(Varscandel.split()[0]) >= pdmin and int(Varscandel.split()[0]) <= pdmax and int(Varscandel.split()[1]) == int(tmp[1]):
                        TP5 += 1
    '''

    dellyCopyOridel = copy.deepcopy(oridel)
    for dellydel in delly:
        if dellydel in dellyCopyOridel:
            TP6 += 1
            dellyCopyOridel.remove(dellydel)
        else:
            for i in range(0, len(dellyCopyOridel)):
                tmp = dellyCopyOridel[i].split()
                if('_' in tmp[0]):
                    pdmin = min(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    pdmax = max(int(tmp[0].split('_')[0]), int(tmp[0].split('_')[1]))
                    if int(dellydel.split()[0]) >= pdmin and int(dellydel.split()[0]) <= pdmax and abs(int(dellydel.split()[1]) - int(tmp[1])) <= tolarence:
                        TP6 += 1
                        dellyCopyOridel.remove(dellyCopyOridel[i])
                        break
                    if abs(int(dellydel.split()[0]) - pdmin) <= tolarence or abs(int(dellydel.split()[0]) - pdmax) <= tolarence:
                        if abs(int(dellydel.split()[1]) - int(tmp[1])) <= tolarence:
                            TP6 += 1
                            dellyCopyOridel.remove(dellyCopyOridel[i])
                            break
                else:
                    if abs(int(dellydel.split()[0]) - int(tmp[0])) <= tolarence:
                        if abs(int(dellydel.split()[1]) - int(tmp[1])) <= tolarence:
                            TP6 += 1
                            dellyCopyOridel.remove(dellyCopyOridel[i])
                            break

    print gatkCopyOridel

    FN1 = len(svdelCopyOridel)
    FP1 = len(pdel) - TP1
    #print pdel
    FN2 = len(pindelCopyOridel)
    FP2 = len(pindel) - TP2
    #print pindel
    FN3 = len(gatkCopyOridel)
    FP3 = len(gatk) - TP3

    FN4 = len(swanCopyOridel)
    FP4 = len(swan) - TP4

    '''
    FN5 = len(oridel) - TP5
    FP5 = len(VarScan) - TP5
    '''

    FN6 = len(dellyCopyOridel)
    FP6 = len(delly) - TP6

    Sensitivity1 = TP1 * 1.0 / (TP1 + FN1)
    Precision1 = TP1 * 1.0 / (TP1 + FP1)
    F11 = 2 * Sensitivity1 * Precision1 * 1.0 / (Sensitivity1 + Precision1)

    Sensitivity2 = TP2 * 1.0 / (TP2 + FN2)
    Precision2 = TP2 * 1.0 / (TP2 + FP2)
    F12 = 2 * Sensitivity2 * Precision2 * 1.0 / (Sensitivity2 + Precision2)

    Sensitivity3 = TP3 * 1.0 / (TP3 + FN3)
    Precision3 = TP3 * 1.0 / (TP3 + FP3)
    if Sensitivity3 * Precision3 == 0:
        F13 = 0
    else:
        F13 = 2 * Sensitivity3 * Precision3 * 1.0 / (Sensitivity3 + Precision3)

    Sensitivity4 = TP4 * 1.0 / (TP4 + FN4)
    Precision4 = TP4 * 1.0 / (TP4 + FP4)
    if Sensitivity4 * Precision4 == 0:
        F14 = 0
    else:
        F14 = 2 * Sensitivity4 * Precision4 * 1.0 / (Sensitivity4 + Precision4)

    '''
    if (TP5 + FN5) == 0:
        Sensitivity5 = 0
    else:
        Sensitivity5 = TP5 * 1.0 / (TP5 + FN5)
    if (TP5 + FP5) == 0:
        Precision5 = 0
    else:
        Precision5 = TP5 * 1.0 / (TP5 + FP5)
    if (Sensitivity5 + Precision5) == 0:
        F15 = 0
    else:
        F15 = 2 * Sensitivity5 * Precision5 * 1.0 / (Sensitivity5 + Precision5)
    '''

    Sensitivity6 = TP6 * 1.0 / (TP6 + FN6)
    Precision6 = TP6 * 1.0 / (TP6 + FP6)
    if Sensitivity6 * Precision6 == 0:
        F16 = 0
    else:
        F16 = 2 * Sensitivity6 * Precision6 * 1.0 / (Sensitivity6 + Precision6)


    b.write("\n预先设置的deletion个数：" + str(len(oridel)) + '\n')
    b.write("case1识别情况：\n")
    b.write("识别的deletion个数：" + str(TP1 + FP1) + '\n')
    b.write("TP：" + str(TP1) + '\n')
    b.write("FP：" + str(FP1) + '\n')
    b.write("FN：" + str(FN1) + '\n')
    b.write("Precision1：" + str(Precision1) + '\n')
    b.write("Sensitivity1：" + str(Sensitivity1) + '\n')
    b.write("F11：" + str(F11) + '\n\n')

    b.write("\npindel识别情况" + '\n')
    b.write("识别的deletion个数：" + str(TP2 + FP2) + '\n')
    b.write("TP：" + str(TP2) + '\n')
    b.write("FP：" + str(FP2) + '\n')
    b.write("FN：" + str(FN2) + '\n')
    b.write("Precision2：" + str(Precision2) + '\n')
    b.write("Sensitivity2：" + str(Sensitivity2) + '\n')
    b.write("F12：" + str(F12) + '\n\n')

    b.write("\ngatk识别情况" + '\n')
    b.write("识别的deletion个数：" + str(TP3 + FP3) + '\n')
    b.write("TP：" + str(TP3) + '\n')
    b.write("FP：" + str(FP3) + '\n')
    b.write("FN：" + str(FN3) + '\n')
    b.write("Precision3：" + str(Precision3) + '\n')
    b.write("Sensitivity3：" + str(Sensitivity3) + '\n')
    b.write("F13：" + str(F13) + '\n\n')

    b.write("\nswan识别情况" + '\n')
    b.write("识别的deletion个数：" + str(TP4 + FP4) + '\n')
    b.write("TP：" + str(TP4) + '\n')
    b.write("FP：" + str(FP4) + '\n')
    b.write("FN：" + str(FN4) + '\n')
    b.write("Precision4：" + str(Precision4) + '\n')
    b.write("Sensitivity4：" + str(Sensitivity4) + '\n')
    b.write("F14：" + str(F14) + '\n\n')

    '''
    b.write("\nVarScan识别情况" + '\n')
    b.write("识别的deletion个数：" + str(TP5 + FP5) + '\n')
    b.write("TP：" + str(TP5) + '\n')
    b.write("FP：" + str(FP5) + '\n')
    b.write("FN：" + str(FN5) + '\n')
    b.write("Precision5：" + str(Precision5) + '\n')
    b.write("Sensitivity5：" + str(Sensitivity5) + '\n')
    b.write("F15：" + str(F15) + '\n\n')
    '''

    b.write("\ndelly识别情况" + '\n')
    b.write("识别的deletion个数：" + str(TP6 + FP6) + '\n')
    b.write("TP：" + str(TP6) + '\n')
    b.write("FP：" + str(FP6) + '\n')
    b.write("FN：" + str(FN6) + '\n')
    b.write("Precision6：" + str(Precision6) + '\n')
    b.write("Sensitivity6：" + str(Sensitivity6) + '\n')
    b.write("F16：" + str(F16) + '\n\n')

    b.close()
    print datetime.datetime.now()












