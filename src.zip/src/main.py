# _*_ coding:utf-8 _*_
#./main chr19_100w.fa s.tab s150.sam 10 10 ./result1/ ./result2/ ./clustered/
from mapping import *
from breaktext import *
from genref import *
from sh import *
import sys
import datetime
import copy

def dealbreakp(breakp, clonf, breakpfl, subCloneReadCount):
    if clonf.has_key(len(breakp)):
        clonf[len(breakp)] = clonf[len(breakp)] + 1
    else:
        clonf[len(breakp)] = 1
    breakpfl.append(breakp)

if __name__ == '__main__':
    print datetime.datetime.now()
    oref = readref(sys.argv[1])
    fun = sys.argv[-1]
    breakpO = []
    breakpO = redbrekp(sys.argv[2])
    u, threetheta, reads_seq, lengthread = guessinsertsize(sys.argv[3], breakpO)

    print "insert size: u = " + str(u) + " 3theta = " + str(threetheta)

    #case1 mapping
    clonf = OrderedDict()#用来存取子克隆数的支持度
    breakfl = []#用于记录所有的deletion信息
    nonemapref = []#用于记录第二种情况的deletion信息
    caseIIbpInfo = OrderedDict()#用来存取预测deletion时得到的第二种情况的断点信息
    subCloneReadCount = []#用于对每一个断点区域各个子克隆read支持数记录
    tolerance = 3
    ref = genref(oref, breakpO, u, lengthread)

    refdel = []
    for k, v in ref.iteritems():
        if len(reads_seq[k]) == 0:
            print k, "no read mapping"
            refdel.append(k)
            continue
        seed_table1 = make_seed_table(v, int(sys.argv[4]))
        reads_mapping(reads_seq[k], seed_table1,  int(sys.argv[4]), int(sys.argv[5]), sys.argv[6], k, v)

    for k in refdel:
        del ref[k]
    #case1
    case1 = set()
    refd = []
    for k, v in ref.iteritems():
        breakp, flag = findBreak(sys.argv[6], k, v, tolerance)#得到第二种情况的断点信息以及第一种情况的断点
        countkey = 0
        for bppkey in breakp.keys():
            if bppkey in case1:
                countkey += 1
            else:
                case1.add(bppkey)
        if countkey == len(breakp) and len(breakp) != 0:
            print "duplicate "
            continue
        if flag == 0:
            print "no two mapping read "
            continue
        if len(breakp) < 1:#当断点的个数<1时为第二中情况
            nonemapref.append(k)
            caseIIbpInfo[k] = "none"
            continue
        elif len(breakp) == 1:
            caseIIbppl = int(breakp.keys()[0].split()[1])
            caseIIbpp = int(breakp.keys()[0].split()[0])
            caseIIbpInfo[k] = str(caseIIbpp) + " " + str(caseIIbppl) + " " + str(len(breakp.values()[0]))
            nonemapref.append(k)
            continue
        dealbreakp(breakp, clonf, breakfl, subCloneReadCount)

    #case II mapping

    case2ref = gecase2ref(oref, nonemapref, caseIIbpInfo, int(sys.argv[8]))
    for k, v in case2ref.iteritems():
        print k
        seed_table2 = make_seed_table(v, int(sys.argv[4]))
        reads_mapping(reads_seq[k], seed_table2,  int(sys.argv[4]), int(sys.argv[5]), sys.argv[7], k, v)
    #case II
    fp = open("case2.txt", 'w')
    fp.write('startPos(or start range)    delent    supports\n')
    fp.close()
    case2 = set()
    for k, v in case2ref.iteritems():
        print k
        snv, readsnv, points, bpp, bppl, halfreflen = Ham(sys.argv[7] + k, k, v, u, threetheta, oref, len(reads_seq[k].values()[0]), reads_seq[k], caseIIbpInfo, case2)
        if halfreflen == 0:
            continue
        count, everysubCloneReadCount = cluster(snv, readsnv, points, lengthread, bpp, bppl, halfreflen, int(sys.argv[9]))
        print count
        if count == 0:
            continue
        if clonf.has_key(count):
            clonf[count] = clonf[count] + 1
        else:
            clonf[count] = 1
        subCloneReadCount.append(everysubCloneReadCount)#将第二种情况下子克隆的read信息保留起来


    clonf = OrderedDict(sorted(clonf.items(), key=lambda e:e[1], reverse=True))
    if len(clonf) > 1:
        if clonf.values()[0] - clonf.values()[1] < 5:
            num = max(clonf.keys()[0], clonf.keys()[1])
        else:
            num = clonf.keys()[0]
    else:
        num = clonf.keys()[0]
    print "subclone num: ", num

    print clonf

    selectBreak(breakfl, num)


    total = []
    subCloneReadCountLast = []

    for i in subCloneReadCount:
        print i



    print datetime.datetime.now()







